# DeepCOVID-ResNet18
COVID-19 Detection using ResNet-18 Transfer Learning Model
